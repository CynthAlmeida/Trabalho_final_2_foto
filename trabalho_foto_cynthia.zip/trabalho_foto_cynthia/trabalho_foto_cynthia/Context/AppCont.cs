﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using trabalho_foto_cynthia.Models;


    namespace trabalho_foto_cynthia.Context
    {
        public class AppCont : DbContext
        {
            public AppCont(DbContextOptions<AppCont> options) : base(options)
            {
            }

            public DbSet<Cadastro_cli> Clientes { get; set; }
        }
    }
